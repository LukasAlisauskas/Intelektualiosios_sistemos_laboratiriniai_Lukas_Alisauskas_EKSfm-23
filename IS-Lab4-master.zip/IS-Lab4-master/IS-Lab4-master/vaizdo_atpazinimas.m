close all
clear all
clc
%% raidžių pavyzdžių nuskaitymas ir požymių skaičiavimas
%% read the image with hand-written characters
pavadinimas = 'train_data3.png';
pozymiai_tinklo_mokymui = pozymiai_raidems_atpazinti(pavadinimas, 3);
%% Atpažintuvo kūrimas
%% Development of character recognizer
% požymiai iš celių masyvo perkeliami į matricą
% take the features from cell-type variable and save into a matrix-type variable
P = cell2mat(pozymiai_tinklo_mokymui);
% sukuriama teisingų atsakymų matrica: 7 raidžių, 3 eilutės mokymui
% create the matrices of correct answers for each line (number of matrices = number of symbol lines)
T = [eye(7), eye(7), eye(7)];%duomenys naudojami mokymui
% sukuriamas SBF tinklas duotiems P ir T sąryšiams
% create an RBF network for classification with 13 neurons, and sigma = 1
tinklas = newrb(P,T,0,1,13);

%% Tinklo patikra | Test of the network (recognizer)
% skaičiuojamas tinklo išėjimas nežinomiems požymiams
% estimate output of the network for unknown symbols (row, that were not used during training)
P2 = P(:,8:14);%reikia vietoj 7 įrašyti raidžių esančių eilutoje skaičių ir prie jo pridėti 1 ir vietoj 14 įrašyti prieštai gautątą skaičių viską padauginti iš 2 (pvs 11 raidzių tai bus 12 ir 22  
Y2 = sim(tinklas, P2);
% ieškoma, kuriame išėjime gauta didžiausia reikšmė
% find which neural network output gives maximum value
[a2, b2] = max(Y2);
%% Rezultato atvaizdavimas
%% Visualize result
% apskaičiuosime raidžių skaičių - požymių P2 stulpelių skaičių
% calculate the total number of symbols in the row
raidziu_sk = size(P2,2);
% rezultatą saugosime kintamajame 'atsakymas'
% we will save the result in variable 'atsakymas'
atsakymas = [];
for k = 1:raidziu_sk
    switch b2(k)
        case 1
            % the symbol here should be the same as written first symbol in your image
            atsakymas = [atsakymas, 'A'];
        case 2
            atsakymas = [atsakymas, 'B'];
        case 3
            atsakymas = [atsakymas, 'C'];
        case 4
            atsakymas = [atsakymas, 'D'];
        case 5
            atsakymas = [atsakymas, 'E'];
        case 6
            atsakymas = [atsakymas, 'F'];
        case 7
            atsakymas = [atsakymas, 'G'];
        % case 8
        %     atsakymas = [atsakymas, 'H'];
        % case 9
        %     atsakymas = [atsakymas, 'I'];
        % case 10
        %     atsakymas = [atsakymas, 'K'];
        % case 11
        %     atsakymas = [atsakymas, 'J'];
    end
end
% pateikime rezultatą komandiniame lange
% show the result in command window
disp(atsakymas)
% % figure(7), text(0.1,0.5,atsakymas,'FontSize',38)
%% žodžio "KADA" požymių išskyrimas 
%% Extract features of the test image
pavadinimas = 'test_fega3.png';
pozymiai_patikrai = pozymiai_raidems_atpazinti(pavadinimas, 1);

%% Raidžių atpažinimas
%% Perform letter/symbol recognition
% požymiai iš celių masyvo perkeliami į matricą
% features from cell-variable are stored to matrix-variable
P2 = cell2mat(pozymiai_patikrai);
% skaičiuojamas tinklo išėjimas nežinomiems požymiams
% estimating neuran network output for newly estimated features
Y2 = sim(tinklas, P2);
% ieškoma, kuriame išėjime gauta didžiausia reikšmė
% searching which output gives maximum value
[a2, b2] = max(Y2);
%% Rezultato atvaizdavimas | Visualization of result
% apskaičiuosime raidžių skaičių - požymių P2 stulpelių skaičių
% calculating number of symbols - number of columns
raidziu_sk = size(P2,2);
% rezultatą saugosime kintamajame 'atsakymas'
atsakymas = [];
for k = 1:raidziu_sk
    switch b2(k)
        case 1
            atsakymas = [atsakymas, 'A'];
        case 2
            atsakymas = [atsakymas, 'B'];
        case 3
            atsakymas = [atsakymas, 'C'];
        case 4
            atsakymas = [atsakymas, 'D'];
        case 5
            atsakymas = [atsakymas, 'E'];
        case 6
            atsakymas = [atsakymas, 'F'];
        case 7
            atsakymas = [atsakymas, 'G'];
        % case 8
        %     atsakymas = [atsakymas, 'H'];
        % case 9
        %     atsakymas = [atsakymas, 'I'];
        % case 10
        %     atsakymas = [atsakymas, 'K'];
        % case 11
        %     atsakymas = [atsakymas, 'J'];
    end
end
% pateikime rezultatą komandiniame lange
% disp(atsakymas)
figure(8), text(0.1,0.5,atsakymas,'FontSize',38), axis off




%% žodžio "FIKCIJA" požymių išskyrimas 
%% extract features for next/another test image
pavadinimas = 'test_ecaga.png';
pozymiai_patikrai = pozymiai_raidems_atpazinti(pavadinimas, 1);

%% Raidžių atpažinimas
% požymiai iš celių masyvo perkeliami į matricą
P2 = cell2mat(pozymiai_patikrai);
% skaičiuojamas tinklo išėjimas nežinomiems požymiams
Y2 = sim(tinklas, P2);
% ieškoma, kuriame išėjime gauta didžiausia reikšmė
[a2, b2] = max(Y2);
%% Rezultato atvaizdavimas
% apskaičiuosime raidžių skaičių - požymių P2 stulpelių skaičių
raidziu_sk = size(P2,2);
% rezultatą saugosime kintamajame 'atsakymas'
atsakymas = [];
for k = 1:raidziu_sk
    switch b2(k)
        case 1
            atsakymas = [atsakymas, 'A'];
        case 2
            atsakymas = [atsakymas, 'B'];
        case 3
            atsakymas = [atsakymas, 'C'];
        case 4
            atsakymas = [atsakymas, 'D'];
        case 5
            atsakymas = [atsakymas, 'E'];
        case 6
            atsakymas = [atsakymas, 'F'];
        case 7
            atsakymas = [atsakymas, 'G'];
        % case 8
        %     atsakymas = [atsakymas, 'H'];
        % case 9
        %     atsakymas = [atsakymas, 'I'];
        % case 10
        %     atsakymas = [atsakymas, 'K'];
        % case 11
        %     atsakymas = [atsakymas, 'J'];
    end
end
% pateikime rezultatą komandiniame lange
% disp(atsakymas)
figure(9), text(0.1,0.5,atsakymas,'FontSize',38), axis off

